package com.learningandroid.alvaro.tictactoe;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.harding.tictactoe.TicTacToeGame;

import org.w3c.dom.Text;

public class TicTacToeActivity extends AppCompatActivity {
    private TicTacToeGame mGame; //for the internal state of the game
    private Button[] mBoardButtons;
    private TextView mInfoTextView;
    static final int DIALOG_DIFFICULTY_ID = 0;
    static final int DIALOG_QUIT_ID = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tic_tac_toe);
        mBoardButtons = new Button[TicTacToeGame.BOARD_SIZE];
        mBoardButtons[0] = (Button) findViewById(R.id.one);
        mBoardButtons[1] = (Button) findViewById(R.id.two);
        mBoardButtons[2] = (Button) findViewById(R.id.three);
        mBoardButtons[3] = (Button) findViewById(R.id.four);
        mBoardButtons[4] = (Button) findViewById(R.id.five);
        mBoardButtons[5] = (Button) findViewById(R.id.six);
        mBoardButtons[6] = (Button) findViewById(R.id.seven);
        mBoardButtons[7] = (Button) findViewById(R.id.eight);
        mBoardButtons[8] = (Button) findViewById(R.id.nine);

        mInfoTextView = (TextView) findViewById(R.id.information);
        mGame = new TicTacToeGame();
        startNewGame();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        //menu.add("New Game");
        return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //startNewGame();
        Dialog dialog;
        switch (item.getItemId()){
            case R.id.new_game:
                startNewGame();
                return true;
            case R.id.ai_difficulty:
                dialog = showDialog(String.valueOf(DIALOG_DIFFICULTY_ID));
                dialog.show();

                return true;
            case R.id.quit:
                dialog = showDialog(String.valueOf(DIALOG_QUIT_ID));
                dialog.show();
                return true;
        }
        return false;
    }

    Dialog showDialog(String option){
        int opt = Integer.parseInt(option);
        Dialog myDialog = null;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        switch (opt){
            case DIALOG_DIFFICULTY_ID:
                final CharSequence[] levels = {
                        getResources().getString(R.string.difficulty_easy),
                        getResources().getString(R.string.difficulty_hard),
                        getResources().getString(R.string.difficulty_expert)
                };

                builder.setTitle(R.string.select_level).setItems(levels,new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // The 'which' argument contains the index position
                        // of the selected item
                        if(which == 0)
                            mGame.setMdifficultyLevel(TicTacToeGame.DifficultyLevel.Easy);
                        else if(which == 1)
                            mGame.setMdifficultyLevel(TicTacToeGame.DifficultyLevel.Hard);
                        else
                            mGame.setMdifficultyLevel(TicTacToeGame.DifficultyLevel.Expert);
                        String selectedLevel = "You chose: " + levels[which] + " level.";

                        Toast.makeText(getApplicationContext(), selectedLevel,
                                Toast.LENGTH_SHORT).show();
                        startNewGame();
                    }
                });
                 return builder.create();

            case DIALOG_QUIT_ID:

                builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User clicked OK button
                        TicTacToeActivity.this.finish();
                        //finish(); //end game
                    }
                });
                builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User cancelled the dialog
                        //nothing happens just cancel the dialog
                    }
                });
                builder.setTitle(R.string.confirmation_on_quit);
                // 3. Get the AlertDialog from create()
                AlertDialog dialog = builder.create();
                return dialog;

        }
        return myDialog;
    }


    private void startNewGame(){
        mGame.clearBoard();
        TicTacToeGame.OVER = false;
        for(int i = 0; i < mBoardButtons.length; i++){
            mBoardButtons[i].setText("");
            mBoardButtons[i].setEnabled(true);
            mBoardButtons[i].setOnClickListener(new ButtonClickListener(i));
            mInfoTextView.setText("You go first");
        }
    }
    private class ButtonClickListener implements View.OnClickListener {
        int location;

        public ButtonClickListener(int location) {
            this.location = location;
        }

        @Override
        public void onClick(View view) {
            if(mBoardButtons[location].isEnabled() &&  !TicTacToeGame.OVER){
                setMove(TicTacToeGame.HUMAN_PLAYER, location);
                int winner = mGame.checkForWinner();
                if(winner == 0){
                    mInfoTextView.setText(R.string.turn_computer);
                    int move = mGame.getComputerMove();
                    setMove(TicTacToeGame.COMPUTER_PLAYER, move);
                    winner = mGame.checkForWinner();
                }

                if(winner == 0){
                    mInfoTextView.setText(R.string.turn_human);
                }

                else if(winner == 1){
                    TicTacToeGame.OVER = true;
                    mInfoTextView.setText(R.string.result_tie);

                }
                else if(winner == 2){
                    TicTacToeGame.OVER = true;
                    mInfoTextView.setText(R.string.result_human_wins);
                }

                else{
                    TicTacToeGame.OVER = true;
                    mInfoTextView.setText(R.string.result_computer_wins);
                }


            }
        }

        private void setMove(char player, int location) {

            mGame.setMove(player, location);
            mBoardButtons[location].setEnabled(false);
            mBoardButtons[location].setText(String.valueOf(player));
            if( player == TicTacToeGame.HUMAN_PLAYER)
                mBoardButtons[location].setTextColor(Color.rgb(0, 200,0));
            else
                mBoardButtons[location].setTextColor(Color.rgb(200, 0,0));
        }


    }

}


