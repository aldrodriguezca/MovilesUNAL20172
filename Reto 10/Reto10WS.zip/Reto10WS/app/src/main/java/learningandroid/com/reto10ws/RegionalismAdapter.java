package learningandroid.com.reto10ws;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.List;

/**
 * Created by Alvaro on 28/11/2017.
 */

public class RegionalismAdapter extends ArrayAdapter<Regionalism>{
    private Context context;
    private List<Regionalism> values;

    public RegionalismAdapter(Context context, List<Regionalism> values){
        super(context, R.layout.custom_layout, values);

        this.context = context;
        this.values = values;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;

        if (row == null) {
            LayoutInflater inflater =
                    (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            row = inflater.inflate(R.layout.custom_layout, parent, false);
        }

        TextView tvTitle = (TextView) row.findViewById(R.id.tvTitle);
        TextView tvCity = (TextView) row.findViewById(R.id.tvCity);

        Regionalism item = values.get(position);
        String city = item.getCity();
        String regionalism = item.getRegionalism();

        tvTitle.setText(regionalism);
        tvCity.setText(city);

        return row;
    }

}
