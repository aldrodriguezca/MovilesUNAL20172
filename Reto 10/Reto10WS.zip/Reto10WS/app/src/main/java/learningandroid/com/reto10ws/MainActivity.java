package learningandroid.com.reto10ws;

import android.graphics.Region;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import retrofit2.Response;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;




import retrofit2.Callback;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    private ListView listView;
    Button btnFilterCity, btnFilterRegionalism;
    EditText etCity, etRegionalism;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etCity = (EditText) findViewById(R.id.etCity);
        etRegionalism = (EditText) findViewById(R.id.etRegionalism);

        listView = (ListView) findViewById(R.id.lvRegionalisms);

        Retrofit.Builder builder = new Retrofit.Builder()
                .baseUrl("https://www.datos.gov.co/resource/3ih9-4uas.json/")
                .addConverterFactory(GsonConverterFactory.create());

        Retrofit retrofit = builder.build();

        OpenDataClient client = retrofit.create(OpenDataClient.class);
        Call<List<Regionalism>> call  =  client.getRegionalisms();

        call.enqueue(new Callback<List<Regionalism>>() {
            @Override
            public void onResponse(Call<List<Regionalism>> call, retrofit2.Response<List<Regionalism>> response) {
                List<Regionalism> regionalisms = response.body();
                Log.d("tamano", String.valueOf(regionalisms));


                //assign to the list view
                listView.setAdapter(new RegionalismAdapter(MainActivity.this, regionalisms));
            }

            @Override
            public void onFailure(Call<List<Regionalism>> call, Throwable t) {

                String waka = t.getCause().toString() + " " + t.getMessage().toString();
                Toast.makeText(MainActivity.this, waka, Toast.LENGTH_LONG).show();

            }
        });
    }

    public void btnFilterCity(View v){
        Log.d("clck", "clicked asdfasdf");

        Retrofit.Builder builder = new Retrofit.Builder()
                .baseUrl("https://www.datos.gov.co/resource/3ih9-4uas.json/")
                .addConverterFactory(GsonConverterFactory.create());

        Retrofit retrofit = builder.build();

        OpenDataClient client = retrofit.create(OpenDataClient.class);
        String theCity = etCity.getText().toString();
        Call<List<Regionalism>> call  =  client.getByCity(theCity);

        call.enqueue(new Callback<List<Regionalism>>() {
            @Override
            public void onResponse(Call<List<Regionalism>> call, retrofit2.Response<List<Regionalism>> response) {
                List<Regionalism> regionalisms = response.body();
                Log.d("tamano", String.valueOf(regionalisms));


                //assign to the list view
                listView.setAdapter(new RegionalismAdapter(MainActivity.this, regionalisms));
            }

            @Override
            public void onFailure(Call<List<Regionalism>> call, Throwable t) {

                String waka = t.getCause().toString() + " " + t.getMessage().toString();
                Toast.makeText(MainActivity.this, waka, Toast.LENGTH_LONG).show();

            }
        });
    }

    public void btnFilterRegionalism(View v){

        Retrofit.Builder builder = new Retrofit.Builder()
                .baseUrl("https://www.datos.gov.co/resource/3ih9-4uas.json/")
                .addConverterFactory(GsonConverterFactory.create());

        Retrofit retrofit = builder.build();

        OpenDataClient client = retrofit.create(OpenDataClient.class);
        String theRegionalism = etRegionalism.getText().toString();
        Call<List<Regionalism>> call  =  client.getByRegionalism(theRegionalism);

        call.enqueue(new Callback<List<Regionalism>>() {
            @Override
            public void onResponse(Call<List<Regionalism>> call, retrofit2.Response<List<Regionalism>> response) {
                List<Regionalism> regionalisms = response.body();
                Log.d("tamano", String.valueOf(regionalisms));


                //assign to the list view
                listView.setAdapter(new RegionalismAdapter(MainActivity.this, regionalisms));
            }

            @Override
            public void onFailure(Call<List<Regionalism>> call, Throwable t) {

                String waka = t.getCause().toString() + " " + t.getMessage().toString();
                Toast.makeText(MainActivity.this, waka, Toast.LENGTH_LONG).show();

            }
        });
    }
}
