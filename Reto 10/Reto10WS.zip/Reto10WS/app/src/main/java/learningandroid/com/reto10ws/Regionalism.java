package learningandroid.com.reto10ws;

/**
 * Created by Alvaro on 28/11/2017.
 */

class Regionalism {
    private String regionalism;
    private Double regionalism_score;
    private String city;
    private Double word_city_score;
    private String tweet;

    public String getRegionalism() {
        return regionalism;
    }

    public void setRegionalism(String regionalism) {
        this.regionalism = regionalism;
    }

    public Double getRegionalism_score() {
        return regionalism_score;
    }

    public void setRegionalism_score(Double regionalism_score) {
        this.regionalism_score = regionalism_score;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Double getWord_city_score() {
        return word_city_score;
    }

    public void setWord_city_score(Double word_city_score) {
        this.word_city_score = word_city_score;
    }

    public String getTweet() {
        return tweet;
    }

    public void setTweet(String tweet) {
        this.tweet = tweet;
    }
}
