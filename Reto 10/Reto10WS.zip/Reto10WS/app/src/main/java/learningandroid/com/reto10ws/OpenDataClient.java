package learningandroid.com.reto10ws;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;
import retrofit2.http.Url;

/**
 * Created by Alvaro on 28/11/2017.
 */

public interface OpenDataClient {
    @GET(".")
    Call<List<Regionalism>> getRegionalisms();

    @GET("?")
    Call<List<Regionalism>> getByCity(@Query("city") String city);

    @GET("?")
    Call<List<Regionalism>> getByRegionalism(@Query("regionalism") String regionalism);
}
