package unal.edu.co.reto8;

/**
 * Created by FABIAN on 13/11/2017.
 */

public interface OnRefreshViewListner {
    public void refreshView();
}
