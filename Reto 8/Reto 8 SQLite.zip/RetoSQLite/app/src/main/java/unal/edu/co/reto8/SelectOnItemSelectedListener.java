package unal.edu.co.reto8;

import android.view.View;
import android.widget.AdapterView;
import android.widget.Toast;

/**
 * Created by FABIAN on 13/11/2017.
 */

public class SelectOnItemSelectedListener implements AdapterView.OnItemSelectedListener {

    public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }

}
