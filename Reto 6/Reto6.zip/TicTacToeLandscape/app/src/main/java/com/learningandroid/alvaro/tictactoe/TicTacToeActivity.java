package com.learningandroid.alvaro.tictactoe;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.support.v7.app.AlertDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.harding.tictactoe.TicTacToeGame;

public class TicTacToeActivity extends AppCompatActivity {
    private TicTacToeGame mGame; //for the internal state of the game
    private Button[] mBoardButtons;
    private TextView mInfoTextView;
    private TextView mTiesTextView;
    private TextView mHwinsTextView;
    private TextView mCwinsTextView;
    static final int DIALOG_DIFFICULTY_ID = 0;
    static final int DIALOG_QUIT_ID = 1;
    private BoardView mBoardView;
    private boolean mGameOver = TicTacToeGame.OVER;
    private MediaPlayer mHumanMediaPlayer;
    private MediaPlayer mComputerMediaPlayer;
    private MediaPlayer tie;
    private MediaPlayer loose;
    private MediaPlayer win;
    private int mHumanWins = 0;
    private int mComputerWins = 0;
    private int mTies = 0;

    private SharedPreferences mPrefs;
    //------
    // Listen for touches on the board
    private View.OnTouchListener mTouchListener = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {

            // Determine which cell was touched
            int col = (int) event.getX() / mBoardView.getBoardCellWidth();
            int row = (int) event.getY() / mBoardView.getBoardCellHeight();
            int pos = row * 3 + col;

            if (!TicTacToeGame.OVER && setMove(TicTacToeGame.HUMAN_PLAYER, pos))	{
                //Checks possible results, acts according to it
                // If no winner yet, let the computer make a move
                //setMove(TicTacToeGame.HUMAN_PLAYER, location);
                int winner = mGame.checkForWinner();
                if(winner == 0){
                    mInfoTextView.setText(R.string.turn_computer);

                    int move = mGame.getComputerMove();
                    setMove(TicTacToeGame.COMPUTER_PLAYER, move);
                    winner = mGame.checkForWinner();
                }

                if(winner == 0){
                    mInfoTextView.setText(R.string.turn_human);
                }

                else if(winner == 1){
                    TicTacToeGame.OVER = true;
                    mInfoTextView.setText(R.string.result_tie);
                    tie.start();
                    mTies++;
                    mTiesTextView.setText(String.valueOf(mTies));
                }
                else if(winner == 2){
                    TicTacToeGame.OVER = true;
                    mInfoTextView.setText(R.string.result_human_wins);
                    win.start();
                    mHumanWins++;
                    mHwinsTextView.setText(String.valueOf(mHumanWins));
                }
                else{
                    TicTacToeGame.OVER = true;
                    mInfoTextView.setText(R.string.result_computer_wins);
                    loose.start();
                    mComputerWins++;
                    mCwinsTextView.setText(String.valueOf(mComputerWins));
                }
            }

// So we aren't notified of continued events when finger is moved
            return false;
        }
    };

    //------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tic_tac_toe);

        mPrefs = getSharedPreferences("ttt_prefs", MODE_PRIVATE);

        // Restore the scores
        mHumanWins = mPrefs.getInt("mHumanWins", 0);
        mComputerWins = mPrefs.getInt("mComputerWins", 0);
        mTies = mPrefs.getInt("mTies", 0);


        mGame = new TicTacToeGame();
        mBoardView = (BoardView) findViewById(R.id.board);
        mBoardView.setmGame(mGame);
        mInfoTextView = (TextView) findViewById(R.id.information);
        mHwinsTextView = (TextView)findViewById(R.id.nHumanWins);
        mCwinsTextView = (TextView) findViewById(R.id.nComputerWins);
        mTiesTextView = (TextView) findViewById(R.id.nTies);

        // Listen for touches on the board
        mBoardView.setOnTouchListener(mTouchListener);


        if(savedInstanceState == null)
            startNewGame();
        else{
            mGame.setBoardState(savedInstanceState.getCharArray("board"));
            mGameOver = savedInstanceState.getBoolean("mGameOver");
            mInfoTextView.setText(savedInstanceState.getCharSequence("info"));
            mTiesTextView.setText(String.valueOf(mTies));
            mHwinsTextView.setText(String.valueOf(mHumanWins));
            mCwinsTextView.setText(String.valueOf(mComputerWins));
            /*mHumanWins = savedInstanceState.getInt("mHumanWins");
            mComputerWins = savedInstanceState.getInt("mComputerWins");
            mTies = savedInstanceState.getInt("mTies");
            mGoFirst = savedInstanceState.getChar("mGoFirst");*/
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        mHumanMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.coin);
        mComputerMediaPlayer = MediaPlayer.create(getApplicationContext(), R.raw.coin);
        tie = MediaPlayer.create(getApplicationContext(), R.raw.tie);
        loose = MediaPlayer.create(getApplicationContext(), R.raw.loose);
        win = MediaPlayer.create(getApplicationContext(), R.raw.winning);
    }

    @Override
    protected void onPause() {
        super.onPause();

        mHumanMediaPlayer.release();
        mComputerMediaPlayer.release();
        tie.release();
        loose.release();
        win.release();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu, menu);
        //menu.add("New Game");
        return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //startNewGame();
        //mComputerMediaPlayer.start();
        Dialog dialog;
        switch (item.getItemId()){
            case R.id.new_game:
                startNewGame();
                return true;
            case R.id.ai_difficulty:
                dialog = showDialog(String.valueOf(DIALOG_DIFFICULTY_ID));
                dialog.show();
                return true;
            case R.id.reset_scores:
                mTies = 0;
                mHumanWins = 0;
                mComputerWins = 0;
                mTiesTextView.setText(String.valueOf(mTies));
                mHwinsTextView.setText(String.valueOf(mHumanWins));
                mCwinsTextView.setText(String.valueOf(mComputerWins));
                return true;
            case R.id.quit:
                dialog = showDialog(String.valueOf(DIALOG_QUIT_ID));
                dialog.show();
                return true;
        }
        return false;
    }

    Dialog showDialog(String option){
        int opt = Integer.parseInt(option);
        Dialog myDialog = null;
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        switch (opt){
            case DIALOG_DIFFICULTY_ID:
                final CharSequence[] levels = {
                        getResources().getString(R.string.difficulty_easy),
                        getResources().getString(R.string.difficulty_hard),
                        getResources().getString(R.string.difficulty_expert)
                };

                builder.setTitle(R.string.select_level).setItems(levels,new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // The 'which' argument contains the index position
                        // of the selected item
                        if(which == 0)
                            mGame.setMdifficultyLevel(TicTacToeGame.DifficultyLevel.Easy);
                        else if(which == 1)
                            mGame.setMdifficultyLevel(TicTacToeGame.DifficultyLevel.Hard);
                        else
                            mGame.setMdifficultyLevel(TicTacToeGame.DifficultyLevel.Expert);
                        String selectedLevel = "You chose: " + levels[which] + " level.";

                        Toast.makeText(getApplicationContext(), selectedLevel,
                                Toast.LENGTH_SHORT).show();
                        startNewGame();
                    }
                });
                 return builder.create();

            case DIALOG_QUIT_ID:

                builder.setPositiveButton(R.string.ok, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User clicked OK button
                        TicTacToeActivity.this.finish();
                        //finish(); //end game
                    }
                });
                builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User cancelled the dialog
                        //nothing happens just cancel the dialog
                    }
                });
                builder.setTitle(R.string.confirmation_on_quit);
                // 3. Get the AlertDialog from create()
                AlertDialog dialog = builder.create();
                return dialog;

        }
        return myDialog;
    }


    private void startNewGame(){
        //mComputerMediaPlayer.start();
        mGame.clearBoard();
        mBoardView.invalidate(); // Redraw the board
        TicTacToeGame.OVER = false;

        mInfoTextView.setText("You go first");
        mTiesTextView.setText(String.valueOf(mTies));
        mHwinsTextView.setText(String.valueOf(mHumanWins));
        mCwinsTextView.setText(String.valueOf(mComputerWins));
    }


        private boolean setMove(char player, int location) {
            if(player == TicTacToeGame.HUMAN_PLAYER)
                mHumanMediaPlayer.start();
            if (mGame.setMove(player, location)) {
                mBoardView.invalidate();   // Redraw the board
                return true;
            }
            return false;
        }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putCharArray("board", mGame.getBoardState());
        outState.putBoolean("mGameOver", mGameOver);
        //outState.putInt("mHumanWins", Integer.valueOf(mHumanWins));
        //outState.putInt("mComputerWins", Integer.valueOf(mComputerWins));
        //outState.putInt("mTies", Integer.valueOf(mTies));
        outState.putCharSequence("info", mInfoTextView.getText());
        //outState.putChar("mGoFirst", mGoFirst);
    }


    //this coul've been done instead of else at onCreate()

   /* @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        mGame.setBoardState(savedInstanceState.getCharArray("board"));
        mGameOver = savedInstanceState.getBoolean("mGameOver");
        mInfoTextView.setText(savedInstanceState.getCharSequence("info"));
//        mHumanWins = savedInstanceState.getInt("mHumanWins");
  //      mComputerWins = savedInstanceState.getInt("mComputerWins");
    //    mTies = savedInstanceState.getInt("mTies");
      //  mGoFirst = savedInstanceState.getChar("mGoFirst");
    }*/

    @Override
    protected void onStop() {
        super.onStop();

        // Save the current scores
        SharedPreferences.Editor ed = mPrefs.edit();
        ed.putInt("mHumanWins", mHumanWins);
        ed.putInt("mComputerWins", mComputerWins);
        ed.putInt("mTies", mTies);
        ed.commit();
    }


}


